﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using EmpEntity;
using EmpException;
using System.Configuration;

namespace EmpDAL
{
    public class EmployeeDaL
    {
        
        public static SqlCommand CreateCommand()
        {
            SqlCommand cmd = null;

            try
            {
                string sqlConnectString = ConfigurationManager.ConnectionStrings["MarathonConnectionstring"].ConnectionString;

                
                SqlConnection con = new SqlConnection();

                con.ConnectionString = sqlConnectString;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = con;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (System.Exception ex)
            {
                throw ex;
            }

            return cmd;
        }
        public static int RegisterEmployee(Employee newEmp)
        {
            int EmpInserted = 0;
            try
            {
                SqlCommand cmd = CreateCommand();
                cmd.CommandText = "[46008413].[RegisterDetails]";
                cmd.Parameters.AddWithValue("@EmployeeId", newEmp.EmployeeId);
                cmd.Parameters.AddWithValue("@EmployeeName", newEmp.EmpName);
                cmd.Parameters.AddWithValue("@Gender", newEmp.Gender);
                cmd.Parameters.AddWithValue("@Location", newEmp.Location);
                cmd.Parameters.AddWithValue("@ContactNo", newEmp.ContactNo);
                cmd.Parameters.AddWithValue("@BloodGroup", newEmp.BloodGrp);
                cmd.Parameters.AddWithValue("@Coverage", newEmp.Coverage);

                cmd.Connection.Open();
                EmpInserted = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return EmpInserted;
        }

    }
}

    