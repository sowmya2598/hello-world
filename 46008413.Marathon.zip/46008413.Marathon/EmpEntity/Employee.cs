﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpEntity
{
    public class Employee
    {


        public string EmployeeId { get; set; }
        public string EmpName { get; set; }
        public string Gender { get; set; }
        public string Location { get; set; }
        public string ContactNo { get; set; }
        public string BloodGrp { get; set; }
        public string Coverage { get; set; }



        //public int EmpId { get; set; }
        //public string EmpName { get; set; }
        //public string Gender { get; set; }
        //public string Location { get; set; }
        //public double ContactNo { get; set; }
        //public string BloodGroup { get; set; }
        //public int Coverage { get; set; }
        //public Employee()
        //{

        //}
    }
}
