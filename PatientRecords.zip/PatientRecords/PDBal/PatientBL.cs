﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PDDal;
using PDException;
using PDEntity;
using System.Data;

namespace PDBal
{
    public class PatientBL
    {
        private static bool ValidatePatient(Patient patient)
        {
            StringBuilder sb = new StringBuilder();
            bool validPatient = true;
            if (patient.Id <= 0)
            {
                validPatient = false;
                sb.Append(Environment.NewLine
                    + "Patient Id should be greater than 0.");
            }
            if (patient.Name == string.Empty)
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "Patient Name can't be empty.");
            }
            if (Convert.ToString(patient.Organ).Length < 1)
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "OrganId must be of 4 digits.");
            }
            if (Convert.ToString(patient.Ward).Length < 1)
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "WardId must be of 4 digits.");
            }
            if (validPatient == false)
            {
                throw new PatientException(sb.ToString());
            }
            return validPatient;

        }

        public static bool AddPatientBL(Patient patient)
        {
            bool patientAdded = false;
            try
            {
                if (ValidatePatient(patient))
                {
                    PatientDAL patientDAL = new PatientDAL();
                    patientAdded = patientDAL.AddPatientDAL(patient);
                    return patientAdded;
                }
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientAdded;
        }

        public static bool UpdatePatientBL(Patient patient)
        {
            bool patientUpdated = false;
            try
            {
                if (ValidatePatient(patient))
                {
                    PatientDAL patientDAL = new PatientDAL();
                    patientUpdated = patientDAL.UpdatePatientDAL(patient);
                    return patientUpdated;
                }
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientUpdated;
        }

        public static bool DeletePatientBL(int patientId)
        {
            bool patientDeleted = false;
            try
            {
                if (patientId > 0)
                {
                    PatientDAL patientDAL = new PatientDAL();
                    patientDeleted = patientDAL.DeletePatientDAL(patientId);
                }
                else
                {
                    throw new PatientException("Patient Id must be greater than 0.");
                }
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientDeleted;
        }

        public static Patient SearchPatientBL(int patientId)
        {
            Patient patient = null;
            try
            {
                if (patientId > 0)
                {
                    PatientDAL patientDAL = new PatientDAL();
                    patient = patientDAL.SearchPatientDAL(patientId);
                }
                else
                {
                    throw new PatientException("Patient Id must be greater than 0.");
                }
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patient;
        }

        public static List<Patient> GetAllPatientBL()
        {
            List<Patient> patientList;
            try
            {
                PatientDAL patientDAL = new PatientDAL();
                patientList = patientDAL.GetAllPatientsDAL();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientList;
        }

        public static DataTable GetOrgansBL()
        {
            DataTable organList;
            try
            {
                PatientDAL patientDAL = new PatientDAL();
                organList = patientDAL.GetOrgansDAL();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return organList;
        }

        public static DataTable GetWardsBL()
        {
            DataTable wardList;
            try
            {
                PatientDAL employeeDAL = new PatientDAL();
               wardList = employeeDAL.GetWardsDAL();
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return wardList;
        }

    }
}
