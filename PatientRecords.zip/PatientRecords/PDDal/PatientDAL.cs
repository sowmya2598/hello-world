﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using PDException;
using PDEntity;
using System.Configuration;

namespace PDDal
{
    public class PatientDAL
    {
     

        public bool AddPatientDAL(Patient objPatient)
        {
            bool patientAdded = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["PatientConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[dbo].[InsertPatient]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_Id = new SqlParameter("@ID", objPatient.Id);
                SqlParameter objSqlParam_Name = new SqlParameter("@Name", objPatient.Name);
                SqlParameter objSqlParam_Organ = new SqlParameter("@Organ", objPatient.Organ);
                SqlParameter objSqlParam_Ward = new SqlParameter("@Ward", objPatient.Ward);
                //
                objCom.Parameters.Add(objSqlParam_Id);
                objCom.Parameters.Add(objSqlParam_Name);
                objCom.Parameters.Add(objSqlParam_Organ);
                objCom.Parameters.Add(objSqlParam_Ward);
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                patientAdded = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new PatientException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return patientAdded;
        }
        public bool UpdatePatientDAL(Patient objPatient)
        {
            bool patientUpdated = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                   ConfigurationManager.ConnectionStrings["PatientConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[dbo].[UpdatePatient]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_Id = new SqlParameter("@ID", objPatient.Id);
                SqlParameter objSqlParam_Name = new SqlParameter("@Name", objPatient.Name);
                SqlParameter objSqlParam_Organ = new SqlParameter("@Organ", objPatient.Organ);
                SqlParameter objSqlParam_Ward = new SqlParameter("@Ward", objPatient.Ward);
                //
                objCom.Parameters.Add(objSqlParam_Id);
                objCom.Parameters.Add(objSqlParam_Name);
                objCom.Parameters.Add(objSqlParam_Organ);
                objCom.Parameters.Add(objSqlParam_Ward);
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                patientUpdated = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new PatientException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return patientUpdated;
        }

        public bool DeletePatientDAL(int id)
        {
            bool patientDeleted = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["PatientConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[dbo].[DeletePatient]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_Id = new SqlParameter("@Id", id);
                //
                objCom.Parameters.Add(objSqlParam_Id);
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                patientDeleted = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new PatientException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return patientDeleted;
        }

        public Patient SearchPatientDAL(int id)
        {
            Patient objPatient = null;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["PatientConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[dbo].[SearchPatient]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_Id = new SqlParameter("@ID", SqlDbType.Int);
                SqlParameter objSqlParam_Name = new SqlParameter("@Name", SqlDbType.VarChar, 50);
                SqlParameter objSqlParam_Organ = new SqlParameter("@Organ", SqlDbType.Int);
                SqlParameter objSqlParam_Ward = new SqlParameter("@Ward", SqlDbType.Int);
                //
                objSqlParam_Id.Direction = ParameterDirection.Input;
                objSqlParam_Name.Direction = ParameterDirection.Output;
                objSqlParam_Organ.Direction = ParameterDirection.Output;
                objSqlParam_Ward.Direction = ParameterDirection.Output;
                //
                objCom.Parameters.Add(objSqlParam_Id);
                objCom.Parameters.Add(objSqlParam_Name);
                objCom.Parameters.Add(objSqlParam_Organ);
                objCom.Parameters.Add(objSqlParam_Ward);
                //
                objSqlParam_Id.Value = id;
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                objPatient = new Patient();
                objPatient.Id = id;
                objPatient.Name = objSqlParam_Name.Value as string;
                objPatient.Organ = Convert.ToInt32(objSqlParam_Organ.Value);
                objPatient.Ward = Convert.ToInt32(objSqlParam_Ward.Value);
            }
            catch (SqlException objSqlEx)
            {
                throw new PatientException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return objPatient;
        }

        public List<Patient> GetAllPatientsDAL()
        {
            List<Patient> objPatients = new List<Patient>();
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["PatientConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[dbo].[SelectPatient]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                while (objDR.Read())
                {
                    Patient objPatient = new Patient();
                    objPatient.Id = Convert.ToInt32(objDR[0]);
                    objPatient.Name = objDR[1] as string;
                    objPatient.Organ = Convert.ToInt32(objDR[2]);
                    objPatient.Ward = Convert.ToInt32(objDR[3]);
                    objPatients.Add(objPatient);
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new PatientException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return objPatients;
        }

        public DataTable GetOrgansDAL()
        {
            DataTable organList = null;
            SqlConnection objCon = null;
            try
            {

                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["PatientConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[dbo].[GetOrgans]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                organList = new DataTable();
                organList.Load(objDR);
            }
            catch (SqlException ex)
            {
                throw new PatientException(ex.Message);
            }
            finally
            {
                objCon.Close();
            }
            return organList;
        }

        public DataTable GetWardsDAL()
        {
            DataTable wardList = null;
            SqlConnection objCon = null;
            try
            {

                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["PatientConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[dbo].[GetWards]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                wardList = new DataTable();
                wardList.Load(objDR);
            }
            catch (SqlException ex)
            {
                throw new PatientException(ex.Message);
            }
            finally
            {
                objCon.Close();
            }
            return wardList;
        }
    }
}
