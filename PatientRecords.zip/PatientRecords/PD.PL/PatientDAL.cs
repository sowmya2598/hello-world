﻿namespace PD.PL
{
    internal class PatientDAL
    {
    }
}