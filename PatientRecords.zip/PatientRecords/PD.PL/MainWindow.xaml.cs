﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PDBal;
using PDException;
using PDEntity;
using System.Data;

namespace PD.PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }



        PatientDAL objPatientDAL;

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            objPatientDAL = new PatientDAL();
            GetOrgans();
            GetWards();
        }

        private void BtnAddPatient_Click(object sender, RoutedEventArgs e)
        {
            AddPatient();
        }

        private void BtnUpdatePatient_Click(object sender, RoutedEventArgs e)
        {
            UpdatePatient();

        }

        private void BtnDeletePatient_Click(object sender, RoutedEventArgs e)
        {
            DeletePatient();
        }

        private void BtnSearchPatient_Click(object sender, RoutedEventArgs e)
        {
            SearchPatient();

        }

        private void BtnGetPatients_Click(object sender, RoutedEventArgs e)
        {
            GetPatients();

        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            Clear();
        }


        private void AddPatient()
        {
            try
            {
                int id;
                string name;
                int organid;
                int wardId;
                //
                bool patientAdded;
                //
                id = Convert.ToInt32(txtId.Text);
                name = txtName.Text;
                organid = Convert.ToInt32(cmbOrgans.SelectedValue);
                wardId = Convert.ToInt32(cmbWards.SelectedValue);
                //
                Patient objPatient = new Patient
                {
                    Id = id,
                    Name = name,
                    Organ = organid,
                    Ward = wardId
                };
                patientAdded = PatientBL.AddPatientBL(objPatient);
                if (patientAdded == true)
                {
                    MessageBox.Show("Patient record added successfully.");
                }
                else
                {
                    MessageBox.Show("Patient record couldn't be added.");
                }
            }
            catch (PatientException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void UpdatePatient()
        {
            try
            {
                int id;
                string name;
                int organid;
                int wardId;
                //
                bool patientUpdated;
                //
                id = Convert.ToInt32(txtId.Text);
                name = txtName.Text;
                organid = Convert.ToInt32(cmbOrgans.SelectedValue);
                wardId = Convert.ToInt32(cmbWards.SelectedValue);
                //
                Patient objPatient = new Patient
                {
                    Id = id,
                    Name = name,
                    Organ = organid,
                    Ward = wardId
                };
                patientUpdated = PatientBL.UpdatePatientBL(objPatient);
                if (patientUpdated == true)
                {
                    MessageBox.Show("Patient record updated successfully.");
                }
                else
                {
                    MessageBox.Show("Patient record couldn't be updated.");
                }
            }
            catch (PatientException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void DeletePatient()
        {
            try
            {
                int id;
                //
                bool patientDeleted;
                //
                id = Convert.ToInt32(txtId.Text);
                //
                patientDeleted = PatientBL.DeletePatientBL(id);
                if (patientDeleted == true)
                {
                    MessageBox.Show("Patient record deleted successfully.");
                }
                else
                {
                    MessageBox.Show("Patient record couldn't be deleted.");
                }
            }
            catch (PatientException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void SearchPatient()
        {



            try
            {
                int Id;
                //
                Patient objPatient;
                //
                Id = Convert.ToInt32(txtId.Text);
                //
                objPatient = PatientBL.SearchPatientBL(Id);
                if (objPatient != null)
                {
                    txtName.Text = objPatient.Name;
                    cmbOrgans.SelectedValue = objPatient.Organ;
                    cmbWards.SelectedValue = objPatient.Ward;
                }
                else
                {
                    MessageBox.Show("Patient record couldn't be found.");
                }
            }
            catch (PatientException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void GetPatients()
        {
            try
            {
                List<Patient> objPatients = PatientBL.GetAllPatientBL();
                if (objPatients != null)
                {
                    dgPatients.ItemsSource = objPatients;
                }
                else
                {
                    MessageBox.Show("No records available.");
                }
            }
            catch (PatientException ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
        private void GetOrgans()
        {
            try
            {
                DataTable organList = PatientBL.GetOrgansBL();
                cmbOrgans.ItemsSource = organList.DefaultView;
                cmbOrgans.DisplayMemberPath = organList.Columns[1].ColumnName;
                cmbOrgans.SelectedValuePath = organList.Columns[0].ColumnName;
            }
            catch (PatientException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void GetWards()
        {
            try
            {
                DataTable wardList = PatientBL.GetWardsBL();
                cmbWards.ItemsSource = wardList.DefaultView;
                cmbWards.DisplayMemberPath = wardList.Columns[1].ColumnName;
                cmbWards.SelectedValuePath = wardList.Columns[0].ColumnName;
            }
            catch (PatientException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void Clear()
        {
            txtId.Clear();
            txtName.Clear();
            cmbOrgans.SelectedIndex = -1;
            cmbWards.SelectedIndex = -1;
            dgPatients.DataContext = null;
        }

        
    }
}