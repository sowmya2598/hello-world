﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PDException
{
    public class PatientException : ApplicationException
    {
        public PatientException() : base()
        {

        }

        public PatientException(string message) : base(message)
        {

        }

        public PatientException(string message, Exception innerException)
            : base(innerException: innerException, message: message)
        {

        }
    }
}
