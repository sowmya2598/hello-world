﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using Entity;
using Exception;
using System.Text.RegularExpressions;

namespace BAL
{
    public class Bal
    {
        private static bool Validate(Customer customer)
        {
            bool Valid = true;
            StringBuilder errorMessages = new StringBuilder();
            bool isCustomerId = Regex.IsMatch(customer.CustomerId.ToString(), "^[0-9]{1,5}$");
            if (!isCustomerId)
            {
                errorMessages.Append("Customer ID must contain not more than 5 digits!");
                Valid = false;
            }
            bool isName = Regex.IsMatch(customer.OrganizationName, "^[A-Z][a-z]");
            if (!isName)
            {
                errorMessages.Append(Environment.NewLine + "Organization Name Should Start with Capital Letter");
                Valid = false;
            }
            bool isContactPersonName = Regex.IsMatch(customer.ContactPerson, "^[A-Z][a-z]");
            if (!isContactPersonName)
            {
                Valid = false;
                errorMessages.Append(Environment.NewLine + "Name Should Start with Capital Letter!");
            }
            bool isContactNo = Regex.IsMatch(customer.ContactNumber.ToString(), "^[0-9]{10}$");
            if (!isContactNo)
            {
                Valid = false;
                errorMessages.Append("Contact No must be of 10 digits!");
            }
            bool isDelAddress = Regex.IsMatch(customer.DeliveryAddress, "^[A-Z][a-z]");
            if (!isDelAddress)
            {
                errorMessages.Append(Environment.NewLine + "Address Should start with Capital Letter");
                Valid = false;
            }
            bool isEmail = Regex.IsMatch(customer.OfficialEmail, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase);
            if (!isEmail)
            {
                errorMessages.Append("Email is Invalid!" + Environment.NewLine);
                Valid = false;
            }                              
            if (!Valid) { throw new CustomerException(errorMessages.ToString()); }
            return Valid;
        }
        

        public static bool AddCustomer(Customer customer )
        {
            bool customerAdded = false;
            try
            {
                if (Validate(customer))
                {
                    Dal Dal = new Dal();
                    customerAdded = Dal.AddCustomer(customer);
                    customerAdded = true;
                }
            }
            catch (CustomerException)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return customerAdded;
        }
       
        public static bool UpdateCustomer (Customer customer)
        {
            bool customerUpdated = false;
            try
            {
                if (Validate(customer))
                {
                    Dal Dal = new Dal();
                    customerUpdated = Dal.UpdateCustomer(customer);
                    customerUpdated = true;
                }
               else
                    throw new CustomerException("Please provide valid Customer details for update");
            }
            catch (CustomerException se)
            {
                throw se;
            }
            catch (SystemException ex)
            { 
                throw ex;
            }
            return customerUpdated;
        }
       
        public static bool DeleteCustomer(int CustId)
        {
            bool customerDeleted = false;
            try
            {
                Dal Dal = new Dal();
                customerDeleted = Dal.DeleteCustomer(CustId);
                customerDeleted = true;
            }
            catch (CustomerException se)
            {
                throw se;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return customerDeleted;
        }
       
        public static Customer SearchCustomer(int CustId)
        {
            Customer customer = null;
            try
            {
                Dal Dal = new Dal();
               customer = Dal.SearchCustomer(CustId);
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
               throw ex;
            }
            return customer;
        }
        
        public static List<Customer> RetrieveCustomer()
        {
            List<Customer> customerList = null;
            try
            {
                customerList = Dal.RetrieveCustomer();
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return customerList;
        }
        
        public static bool SerializeCustomer()
        {
            bool customerSerialized = false;
            try
            {
                customerSerialized = Dal.SerializeCustomer();
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return customerSerialized;
        }
        

        public static List<Customer> DeserializeCustomer()
        {
            List<Customer> customerList = null;
            try
            {
                customerList = Dal.DeSerializeCustomer();
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return customerList;
        }
       
    private static bool Validate(Dealer deal)
    {
        bool Valid = true;
        StringBuilder errorMessages = new StringBuilder();
        bool isCustomerId = Regex.IsMatch(deal.DealerCode.ToString(), "^[0-9]{1,5}$");
        if (!isCustomerId)
        {
            errorMessages.Append("Dealer code must contain not more than 5 digits!");
            Valid = false;
        }
        bool isName = Regex.IsMatch(deal.OrganizationName, "^[A-Z][a-z]");
        if (!isName)
        {
            errorMessages.Append(Environment.NewLine + "Organization Name Should Start with Capital Letter");
            Valid = false;
        }
        bool isContactPersonName = Regex.IsMatch(deal.ContactPerson, "^[A-Z][a-z]");
        if (!isContactPersonName)
        {
            Valid = false;
            errorMessages.Append(Environment.NewLine + "Name Should Start with Capital Letter!");
        }
        bool isContactNo = Regex.IsMatch(deal.ContactNumber.ToString(), "^[0-9]{10}$");
        if (!isContactNo)
        {
            Valid = false;
            errorMessages.Append("Contact No must be of 10 digits!");
        }
        bool isDelAddress = Regex.IsMatch(deal.DeliveryAddress, "^[A-Z][a-z]");
        if (!isDelAddress)
        {
            errorMessages.Append(Environment.NewLine + "Address Should start with Capital Letter");
            Valid = false;
        }
        bool isEmail = Regex.IsMatch(deal.OfficialEmail, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase);
        if (!isEmail)
        {
            errorMessages.Append("Email is Invalid!" + Environment.NewLine);
            Valid = false;
        }
        if (!Valid) { throw new CustomerException(errorMessages.ToString()); }
        return Valid;
    }
    public static bool AddDealer(Dealer deal)
    {
        bool dealAdded = false;
        try
        {
            if (Validate(deal))
            {
                Dal Dal = new Dal();
                dealAdded = Dal.AddDealer(deal);
                dealAdded = true;
            }
        }
        catch (DealerException)
        {
            throw;
        }
        catch (SystemException ex)
        {
            throw ex;
        }
        return dealAdded;
    }
    public static bool UpdateDealer(Dealer deal)
    {
        bool dealUpdated = false;
        try
        {
            if (Validate(deal))
            {
                Dal Dal = new Dal();
                dealUpdated = Dal.UpdateDealer(deal);
                dealUpdated = true;
            }
            else
                throw new DealerException("Please provide valid Dealer details for update");
        }
        catch (DealerException se)
        {
            throw se;
        }
        catch (SystemException ex)
        {
            throw ex;
        }
        return dealUpdated;
    }
    public static bool DeleteDealer(int DealId)
    {
        bool dealDeleted = false;
        try
        {
            Dal Dal = new Dal();
            dealDeleted = Dal.DeleteDealer(DealId);
            dealDeleted = true;
        }
        catch (DealerException se)
        {
            throw se;
        }
        catch (SystemException ex)
        {
            throw ex;
        }
        return dealDeleted;
    }
    public static Dealer SearchDealer(int DealId)
    {
        Dealer deal = null;
        try
        {
            Dal Dal = new Dal();
            deal = Dal.SearchDealer(DealId);
        }
        catch (DealerException ex)
        {
            throw ex;
        }
        catch (SystemException ex)
        {
            throw ex;
        }
        return deal;
    }
    public static List<Dealer> RetrieveDealer()
    {
        List<Dealer> dealList = null;
        try
        {
            dealList = Dal.RetrieveDealer();
        }
        catch (DealerException ex)
        {
            throw ex;
        }
        catch (SystemException ex)
        {
            throw ex;
        }
        return dealList;
    }
    public static bool SerializeDealer()
    {
        bool dealSerialized = false;
        try
        {
            dealSerialized = Dal.SerializeDealer();
        }
        catch (DealerException ex)
        {
            throw ex;
        }
        catch (SystemException ex)
        {
            throw ex;
        }
        return dealSerialized;
    }
        public static List<Dealer> DeserializeDealer()
        {
            List<Dealer> dealList = null;
            try
            {
                dealList = Dal.DeSerializeDealer();
            }
            catch (DealerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return dealList;
        }
        //private static bool Validate(Product prod )
        //{
        //    bool Valid = true;
        //    StringBuilder errorMessages = new StringBuilder();
        //    bool isCustomerId = Regex.IsMatch(deal.DealerCode.ToString(), "^[0-9]{1,5}$");
        //    if (!isCustomerId)
        //    {
        //        errorMessages.Append("Dealer code must contain not more than 5 digits!");
        //        Valid = false;
        //    }
        //    bool isName = Regex.IsMatch(deal.OrganizationName, "^[A-Z][a-z]");
        //    if (!isName)
        //    {
        //        errorMessages.Append(Environment.NewLine + "Organization Name Should Start with Capital Letter");
        //        Valid = false;
        //    }
        //    bool isContactPersonName = Regex.IsMatch(deal.ContactPerson, "^[A-Z][a-z]");
        //    if (!isContactPersonName)
        //    {
        //        Valid = false;
        //        errorMessages.Append(Environment.NewLine + "Name Should Start with Capital Letter!");
        //    }
        //    bool isContactNo = Regex.IsMatch(deal.ContactNumber.ToString(), "^[0-9]{10}$");
        //    if (!isContactNo)
        //    {
        //        Valid = false;
        //        errorMessages.Append("Contact No must be of 10 digits!");
        //    }
        //    bool isDelAddress = Regex.IsMatch(deal.DeliveryAddress, "^[A-Z][a-z]");
        //    if (!isDelAddress)
        //    {
        //        errorMessages.Append(Environment.NewLine + "Address Should start with Capital Letter");
        //        Valid = false;
        //    }
        //    bool isEmail = Regex.IsMatch(deal.OfficialEmail, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase);
        //    if (!isEmail)
        //    {
        //        errorMessages.Append("Email is Invalid!" + Environment.NewLine);
        //        Valid = false;
        //    }
        //    if (!Valid) { throw new CustomerException(errorMessages.ToString()); }
        //    return Valid;
        //}
        //public static bool AddDealer(Dealer deal)
        //{
        //    bool dealAdded = false;
        //    try
        //    {
        //        if (Validate(deal))
        //        {
        //            Dal Dal = new Dal();
        //            dealAdded = Dal.AddDealer(deal);
        //            dealAdded = true;
        //        }
        //    }
        //    catch (DealerException)
        //    {
        //        throw;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }
        //    return dealAdded;
        //}
        //public static bool UpdateDealer(Dealer deal)
        //{
        //    bool dealUpdated = false;
        //    try
        //    {
        //        if (Validate(deal))
        //        {
        //            Dal Dal = new Dal();
        //            dealUpdated = Dal.UpdateDealer(deal);
        //            dealUpdated = true;
        //        }
        //        else
        //            throw new DealerException("Please provide valid Dealer details for update");
        //    }
        //    catch (DealerException se)
        //    {
        //        throw se;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }
        //    return dealUpdated;
        //}
        //public static bool DeleteDealer(int DealId)
        //{
        //    bool dealDeleted = false;
        //    try
        //    {
        //        Dal Dal = new Dal();
        //        dealDeleted = Dal.DeleteDealer(DealId);
        //        dealDeleted = true;
        //    }
        //    catch (DealerException se)
        //    {
        //        throw se;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }
        //    return dealDeleted;
        //}
        //public static Dealer SearchDealer(int DealId)
        //{
        //    Dealer deal = null;
        //    try
        //    {
        //        Dal Dal = new Dal();
        //        deal = Dal.SearchDealer(DealId);
        //    }
        //    catch (DealerException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }
        //    return deal;
        //}
        //public static List<Dealer> RetrieveDealer()
        //{
        //    List<Dealer> dealList = null;
        //    try
        //    {
        //        dealList = Dal.RetrieveDealer();
        //    }
        //    catch (DealerException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }
        //    return dealList;
        //}
        //public static bool SerializeDealer()
        //{
        //    bool dealSerialized = false;
        //    try
        //    {
        //        dealSerialized = Dal.SerializeDealer();
        //    }
        //    catch (DealerException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }
        //    return dealSerialized;
        //}
        //public static List<Dealer> DeserializeDealer()
        //{
        //    List<Dealer> dealList = null;
        //    try
        //    {
        //        dealList = Dal.DeSerializeDealer();
        //    }
        //    catch (DealerException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }
        //    return dealList;
        //}
    }
}

