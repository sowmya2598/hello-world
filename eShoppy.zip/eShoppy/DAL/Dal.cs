﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entity;
using Exception;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;


namespace DAL
{
    public class Dal
    {
        public static List<Customer> customers  = new List<Customer>();
        public static List<Dealer> dealers = new List<Dealer>();
        public static List<Product> products = new List<Product>();

        public bool AddCustomer(Customer customer)
        {
            bool customerAdded = false;
            try
            {
                customers.Add(customer);
                customerAdded = true;
            }
            catch (CustomerException se)
            {
                throw se;
            }
            catch (SystemException ex)
            {
                throw ex;
            }        
            return customerAdded;
        }
        

        public static bool UpdateCustomer(Customer customer)
        {
          bool customerUpdated = false;
            try
            {
               for (int i = 0; i < customers.Count; i++)
                {
                    if (customers[i].CustomerId == customer.CustomerId)
                    {
                        customers[i].OrganizationName = customer.OrganizationName;
                        customers[i].ContactPerson = customer.ContactPerson;
                        customers[i].ContactNumber= customer.ContactNumber;
                        customers[i].DeliveryAddress = customer.DeliveryAddress;
                        customers[i].OfficialEmail = customer.OfficialEmail;
                        customers[i].Username = customer.Username;
                        customers[i].Password = customer.Password;
                        customerUpdated = true;
                    }
                }
            }
            catch (CustomerException se)
            {
                throw se;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return customerUpdated;
        }
        
        public static bool DeleteCustomer(int CustId)
        {
            bool customerDeleted = false;
            try
            {
               Customer customer = customers.Find(s => s.CustomerId == CustId);
                if (customer != null)
                {
                    customers.Remove(customer);
                   customerDeleted = true;
                }
            }
            catch (CustomerException se)
            {
                throw se;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return customerDeleted;
        }

       

        public static Customer SearchCustomer(int CustId )
        {
            Customer customer = null;
            try
            {
                customer = customers.Find(s => s.CustomerId == CustId);
            }
            catch (CustomerException se)
            {
                throw se;
            }
            catch (SystemException ex)
            {
                throw ex;
           }
            return customer;
        }
       
        public static List<Customer> RetrieveCustomer()
        {
            return customers;
        }
        
        public static bool SerializeCustomer()
        {
            bool customerSerialized = false;
            try
            {
                FileStream fs = new FileStream("customer.txt", FileMode.Create, FileAccess.Write);
                BinaryFormatter bf = new BinaryFormatter();
                bf.Serialize(fs, customers);
                fs.Close();
                customerSerialized = true;
            }
            catch (CustomerException se)
            {
               throw se;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return customerSerialized;
        }
        
        public static List<Customer> DeSerializeCustomer()
        {
            List<Customer> des = null;
            try
           {
                FileStream fs = new FileStream("customer.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter bf = new BinaryFormatter();
                des = bf.Deserialize(fs) as List<Customer>;
                fs.Close();
            }
            catch (CustomerException se)
            {
                throw se;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return des;
        }

        
        public bool AddDealer(Dealer deal)
        {
            bool dealAdded = false;
            try
            {
                dealers.Add(deal);
                dealAdded = true;
            }
            catch (DealerException se)
            {
                throw se;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return dealAdded;
        }
        public static bool UpdateDealer(Dealer deal)
        {
            bool dealUpdated = false;
            try
            {
                for (int i = 0; i < dealers.Count; i++)
                {
                    if (dealers[i].DealerCode == deal.DealerCode)
                    {
                        dealers[i].OrganizationName = deal.OrganizationName;
                        dealers[i].ContactPerson = deal.ContactPerson;
                        dealers[i].ContactNumber = deal.ContactNumber;
                        dealers[i].DeliveryAddress = deal.DeliveryAddress;
                        dealers[i].WarehouseAddress = deal.WarehouseAddress;
                        dealers[i].OfficialEmail = deal.OfficialEmail;
                        dealers[i].Username = deal.Username;
                        dealers[i].Password = deal.Password;
                        dealUpdated = true;
                    }
                }
            }
            catch (DealerException se)
            {
                throw se;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return dealUpdated;
        }
        public static bool DeleteDealer(int DealId)
        {
            bool dealDeleted = false;
            try
            {
                Dealer deal = dealers.Find(s => s.DealerCode == DealId);
                if (deal != null)
                {
                    dealers.Remove(deal);
                    dealDeleted = true;
                }
            }
            catch (DealerException se)
            {
                throw se;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return dealDeleted;
        }
        public static Dealer SearchDealer(int DealId)
        {
            Dealer deal = null;
            try
            {
                deal = dealers.Find(s => s.DealerCode == DealId);
            }
            catch (DealerException se)
            {
                throw se;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return deal;
        }
        public static List<Dealer> RetrieveDealer()
        {
            return dealers;
        }
        public static bool SerializeDealer()
        {
            bool dealSerialized = false;
            try
            {
                FileStream fs = new FileStream("dealer.txt", FileMode.Create, FileAccess.Write);
                BinaryFormatter bf = new BinaryFormatter();
                bf.Serialize(fs, dealers);
                fs.Close();
                dealSerialized = true;
            }
            catch (DealerException se)
            {
                throw se;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return dealSerialized;
        }
        public static List<Dealer> DeSerializeDealer()
        {
            List<Dealer> des = null;
            try
            {
                FileStream fs = new FileStream("dealer.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter bf = new BinaryFormatter();
                des = bf.Deserialize(fs) as List<Dealer>;
                fs.Close();
            }
            catch (DealerException se)
            {
                throw se;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return des;
        }
        public bool AddProduct(Product prod)
        {
            bool prodAdded = false;
            try
            {
                products.Add(prod);
                prodAdded = true;
            }
            catch (ProductException se)
            {
                throw se;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return prodAdded;
        }
        public static bool UpdateProduct (Product prod)
        {
            bool prodUpdated = false;
            try
            {
                for (int i = 0; i < products.Count; i++)
                {
                    if (products[i].ProductId == prod.ProductId)
                    {
                        products[i].ProductName = prod.ProductName;
                        products[i].Quantity = prod.Quantity;
                        products[i].Price = prod.Price;
                        products[i].DateandTimeofProductAdded = prod.DateandTimeofProductAdded;                                         
                        prodUpdated = true;
                    }
                }
            }
            catch (ProductException se)
            {
                throw se;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return prodUpdated;
        }
        public static bool DeleteProduct(int ProdId)
        {
            bool prodDeleted = false;
            try
            {
                Product prod = products.Find(s => s.ProductId == ProdId);
                if (prod != null)
                {
                    products.Remove(prod);
                    prodDeleted = true;
                }
            }
            catch (ProductException se)
            {
                throw se;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return prodDeleted;
        }
        public static Product SearchProduct(int ProdId)
        {
           Product prod = null;
            try
            {
                prod = products.Find(s => s.ProductId == ProdId);
            }
            catch (ProductException se)
            {
                throw se;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return prod;
        }
        public static List<Product> RetrieveProduct()
        {
            return products;
        }
        public static bool SerializeProduct()
        {
            bool prodSerialized = false;
            try
            {
                FileStream fs = new FileStream("product.txt", FileMode.Create, FileAccess.Write);
                BinaryFormatter bf = new BinaryFormatter();
                bf.Serialize(fs, dealers);
                fs.Close();
                prodSerialized = true;
            }
            catch (ProductException se)
            {
                throw se;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return prodSerialized;
        }
        public static List<Product> DeSerializeProduct()
        {
            List<Product> des = null;
            try
            {
                FileStream fs = new FileStream("product.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter bf = new BinaryFormatter();
                des = bf.Deserialize(fs) as List<Product>;
                fs.Close();
            }
            catch (ProductException se)
            {
                throw se;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return des;
        }
    }

}
    

