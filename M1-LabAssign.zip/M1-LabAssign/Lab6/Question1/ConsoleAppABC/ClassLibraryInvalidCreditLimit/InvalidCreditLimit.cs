﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryInvalidCreditLimit
{
    public class InvalidCreditLimit:ApplicationException
    {
        public InvalidCreditLimit()
        {

        }
        public InvalidCreditLimit(string str) : base(str)
        {

        }

        public InvalidCreditLimit(string str, Exception innerexce) : base(str, innerexce)
        {

        }
    }
}
