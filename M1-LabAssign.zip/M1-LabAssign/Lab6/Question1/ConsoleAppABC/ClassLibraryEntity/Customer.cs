﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibraryInvalidCreditLimit;

namespace ClassLibraryEntity
{
    public class Customer
    {
        private int customerid;
        public int CustomerID { get; set; }
        private string customername;
        public string CustomerName { get; set; }
        private string address; 
        public string Address { get; set; }
        private string city;
        public string City { get; set; }
        private string phone;
        public string Phone { get; set; }
        private double creditlimit;
        public double CreditLimit
        {
            get
            {
                return creditlimit;
            }
            set
            {
                if ((value > 0) && (value <= 50000))
                {
                    creditlimit = value;

                }
                else
                {
                    CreditLimit = 0;
                    throw new InvalidCreditLimit("Invalid credit limit exception");
                }
            }
        }

        public Customer()
        {

        }

        public Customer(int cid, string name, string add, string city, string phone, double credit)
        {
            this.CustomerID = cid;
            this.CustomerName = name;
            this.Address = add;
            this.City = city;
            this.Phone = phone;
            this.CreditLimit = credit;
        }

        public void Display()
        {
            Console.WriteLine("CustomerID- " +CustomerID+ "\n" +"Customer Name- " +CustomerName+ "\n" +"Customer Address- " +Address+ "\n" +"City- "+City+"\n"+"Phone number- "+Phone+"\n"+"Credit Limit- "+CreditLimit);
        }
    }
}
