﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibraryMyException;
using ProductMockEntity;

namespace ConsoleAppPL
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Enter Product ID");
                int pid = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Product Name");
                string pname = Console.ReadLine();
                Console.WriteLine("Enter product price");
                double price = double.Parse(Console.ReadLine());
                ProductMock obj = new ProductMock(pid, pname, price);
                obj.Display();

                
            }
            catch(ClassLibraryMyException.MyException ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }
    }
}
