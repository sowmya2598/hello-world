﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibraryMyException;
using System.Text.RegularExpressions;

namespace ProductMockEntity
{
    public class ProductMock
    {
        private int productid;
        public int ProductID
        {
            get
            {
                return productid;
            }

            set
            {
                if (value > 0)
                {
                    productid = value;
                }
                else
                {
                    productid = 0;
                    throw new MyException("Inavlid product id");
                }
            }
        }

        private string productname;
        public string ProductName
        {
            get
            {
                return productname;
            }
            set
            {
                if (value != String.Empty)
                {
                    productname = value;
                }
                else if(!Regex.IsMatch(value, "^[A-Za-z0-9]+"))
                {
                    throw new MyException("Invalid Product name");
                }

                
            }
        }

        private double price;
        public double Price
        {
            get
            {
                return price;
            }
            set
            {
                if (value > 0)
                {
                    price = value;
                }
                else
                {
                    price = 0;
                    throw new MyException("Invalid price");
                }
            }
        }

        public ProductMock(int pid, string name, double pprice)
        {
            this.ProductID = pid;
            this.ProductName = name;
            this.Price = pprice;
        }

        public void Display()
        {
            Console.WriteLine("Product ID- " + productid + "\n" + "Product Name- " + productname + "\n" + "Price- " + price);
        }

        
        



    }
}
