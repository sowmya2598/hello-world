﻿using System;

using System.Collections.Generic;

using System.Linq;

using System.Text;

using System.Threading.Tasks;

using System.IO;

namespace ConsoleApp1

{

    class Program

    {

        public static void Main(string[] args)

        {

            //string fileName = "Sample.txt";

            string sourcePath = @"D:\Users\ADM-IG-HWDLAB1D\Desktop\abc\Banglore.txt";

            string targetPath = @"D:\Users\ADM-IG-HWDLAB1D\Desktop\abc\Pune.txt";



            //string sourceFile = System.IO.Path.Combine(sourcePath, fileName);

            //string destFile = System.IO.Path.Combine(targetPath, fileName);

            try

            {

                File.Copy(sourcePath, targetPath);

                Console.WriteLine("Copied.....Press any key to exit.");

            }

            catch (Exception e)

            {

                Console.WriteLine("Exception:" + e.Message);

            }

            Console.ReadKey();

        }

    }
}