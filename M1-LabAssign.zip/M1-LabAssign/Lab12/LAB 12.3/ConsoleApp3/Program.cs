﻿using System;

using System.Collections.Generic;

using System.Linq;

using System.Text;

using System.Threading.Tasks;

using System.IO;

using DetailsEntity;

namespace ConsoleApp3

{

    class Program

    {

        public static void Main(string[] args)

        {

            string source = @"D:\Users\ADM-IG-HWDLAB1D\Desktop\abc";

            DirectoryInfo d1 = new DirectoryInfo(source);

            d1.Create();

            DirectoryInfo sub1 = d1.CreateSubdirectory(@"Chennai");

            DirectoryInfo sub2 = d1.CreateSubdirectory(@"Banglore");

            DirectoryInfo sub3 = d1.CreateSubdirectory(@"Pune");

            DirectoryInfo sub4 = d1.CreateSubdirectory(@"Mumbai");

            FileInfo f1 = new FileInfo(@"D:\Users\ADM-IG-HWDLAB1D\Desktop\abc\Chennai.txt");



            FileInfo f2 = new FileInfo(@"D:\Users\ADM-IG-HWDLAB1D\Desktop\abc\Banglore.txt");



            FileInfo f3 = new FileInfo(@"D:\Users\ADM-IG-HWDLAB1D\Desktop\abc\Pune.txt");



            FileInfo f4 = new FileInfo(@"D:\Users\ADM-IG-HWDLAB1D\Desktop\abc\Mumbai.txt");





            Details d = new Details();

            Console.WriteLine("Enter Student Name :");

            d.Name = Console.ReadLine();





            Console.WriteLine("Enter Degree Name :");

            d.Degree = Console.ReadLine();



            Console.WriteLine("Enter Course :");

            d.Course = Console.ReadLine();



            Console.WriteLine("Enter Location :");

            d.Location = Console.ReadLine();







            switch (d.Location)

            {



                case "Chennai":

                    using (StreamWriter sw = f1.CreateText())

                    {



                        sw.WriteLine($"Name : {d.Name}\nDegree: {d.Degree}\nCourse : {d.Course}\nLocation : {d.Location} ");

                        sw.Close();

                    }

                    break;

                case "Mumbai":

                    using (StreamWriter sw = f4.CreateText())

                    {



                        sw.WriteLine($"Name : {d.Name}\nDegree: {d.Degree}\nCourse : {d.Course}\nLocation : {d.Location} ");

                        sw.Close();

                    }

                    break;

                case "Banglore":

                    using (StreamWriter sw = f2.CreateText())

                    {



                        sw.WriteLine($"Name : {d.Name}\nDegree: {d.Degree}\nCourse : {d.Course}\nLocation : {d.Location} ");

                        sw.Close();

                    }

                    break;

                case "Pune":

                    using (StreamWriter sw = f3.CreateText())

                    {



                        sw.WriteLine($"Name : {d.Name}\nDegree: {d.Degree}\nCourse : {d.Course}\nLocation : {d.Location} ");

                        sw.Close();

                    }

                    break;



                default:

                    break;

            }







            Console.ReadKey();

        }



    }

}