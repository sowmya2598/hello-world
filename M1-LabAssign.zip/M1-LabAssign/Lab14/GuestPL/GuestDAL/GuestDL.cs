﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;
using GuestEntity;
using System.IO;
namespace GuestDAL
{
    public class GuestDL
    {
        public static List<Guest> guestList = new List<Guest>();
        public static string filename = "GuestList";
        public static bool AddGuestDAL(Guest newGuest)
        {
            bool guestAdd = false;
            try
            {
                guestList.Add(newGuest);
                guestAdd = true;
                SetSerialization();
            }
            catch(Exception e)
            {
                throw new GuestException.GuestEx(e.Message);
            }
            return guestAdd;
        }
        public static List<Guest> ListAllGuestDAL()
        {
            return guestList;
        }

        public static bool UpdateGuestDAL(Guest updateGuest)
        {
            bool updateguest = false;
            try
            {
                for(int i = 0; i < guestList.Count; i++)
                {
                    Guest guest = guestList[i];
                    if (guest.GuestID == updateGuest.GuestID)
                    {
                        guestList[i] = updateGuest;
                        SetSerialization();
                        break;
                    }
                }
                updateguest = true;
            }
            catch(Exception e)
            {
                throw new GuestException.GuestEx(e.Message);
            }
            return updateguest;
        }

        public static Guest SearchGuestDAL(string searchGuest)
        {
            Guest searchguest = null;
            try
            {
                for(int i = 0; i < guestList.Count; i++)
                {
                    Guest guest = guestList[i];
                    if (guest.GuestID == searchGuest)
                    {
                        searchguest = guestList[i];
                        break;
                    }
                }
            }
            catch(Exception e)
            {
                throw new GuestException.GuestEx(e.Message);
            }
            return searchguest;
        }

        public static bool DeleteGuestDAL(string delGuest)
        {
            bool guestdel = false;
            try
            {
                for(int i = 0; i < guestList.Count; i++)
                {
                    Guest guest = guestList[i];
                    if (guest.GuestID == delGuest)
                    {
                        guestList.RemoveAt(i);
                        guestdel = true;
                        SetSerialization();
                        break;
                    }
                }
            }catch(Exception e)
            {
                throw new GuestException.GuestEx(e.Message);
            }
            return guestdel;
        }

        public static void SetSerialization()
        {
            try
            {
                using (Stream file = File.Open(filename, FileMode.Create))
                {
                    BinaryFormatter bf = new BinaryFormatter();
                    bf.Serialize(file, guestList);
                    file.Close();
                }
            }
            catch (FileNotFoundException ex)
            {
                Console.WriteLine("File not found.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Setting List if the file already exists
        public static void SetList()
        {
            DeserializeFile();
        }
        public static void DeserializeFile()
        {
            try
            {

                using (Stream file = File.Open(Directory.GetCurrentDirectory() + "\\" + filename, FileMode.Open))
                {
                    BinaryFormatter bf = new BinaryFormatter();
                    guestList = bf.Deserialize(file) as List<Guest>;
                    file.Close();
                }
            }
            catch (FileNotFoundException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
