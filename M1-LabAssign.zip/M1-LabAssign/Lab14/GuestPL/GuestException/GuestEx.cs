﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GuestException
{
    public class GuestEx:ApplicationException
    {
        public GuestEx() : base() { }
        public GuestEx(string message) : base(message) { }
        public GuestEx(string message,Exception innerException) : base(message, innerException) { }
    }
}