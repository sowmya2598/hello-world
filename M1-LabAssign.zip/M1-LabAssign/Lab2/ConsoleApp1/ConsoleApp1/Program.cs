﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
       
        struct Structure
        {
            public int Number;

            public Structure(int number1)
            {
                Number = number1;
            }
            

            public int Square()
            {
                
                return Number * Number;
            }

            public int Cube()
            {
                
                return Number * Number * Number;
            }
        }

        static void Main(string[] args)
        {
            Console.WriteLine("enter a number to determine square and cube");
            int num = int.Parse(Console.ReadLine());
            Structure s = new Structure(num);
            Console.WriteLine("Square- " + s.Square());
            Console.WriteLine("Cube- " + s.Cube());
            Console.ReadKey();



        }
    }

}

