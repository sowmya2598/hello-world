﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class StJoseph
    {
        static void Main(string[] args)
        {

            char choice;
            do

            {


                Console.WriteLine("Please enter roll number");
                int rollnum = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Please enter Name");
                string name = Console.ReadLine();
                Console.WriteLine("Please enter age");
                byte age = Convert.ToByte(Console.ReadLine());
                Console.WriteLine("Please enter Gender");
                char gen = Convert.ToChar(Console.ReadLine());
                Console.WriteLine("Please enter DOB");
                DateTime DOB = Convert.ToDateTime(Console.ReadLine());
                Console.WriteLine("Please enter Address");
                string add = Console.ReadLine();
                Console.WriteLine("Please enter percentage");
                float per = float.Parse(Console.ReadLine());

                Console.WriteLine("Roll number- " + rollnum + "\n" + "Name- " + name + "\n" + "Age- " + age + "\n" + "Gender- " + gen + "\n" + "Date of Birth- " + DOB + "\n" + "Address- " + add + "\n" + "Percentage- " + per);

                Console.WriteLine("do you want to enter again");
                Console.WriteLine("Y for Yes");
                choice = Convert.ToChar(Console.ReadLine());


            }
            while (choice == 'Y' || choice == 'y');
            {

            }
            
            
           
            Console.ReadKey();




        }
    }
}
