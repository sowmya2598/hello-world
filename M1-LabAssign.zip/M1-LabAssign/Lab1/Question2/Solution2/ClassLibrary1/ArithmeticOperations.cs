﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class ArithmeticOperations
    {
        public void Math(int a, int b, char ch)
        {
            switch (ch)
            {
                case '+':
                    Console.WriteLine("The sum is " + (a + b));
                    break;
                case '-':
                    Console.WriteLine("The sum is " + (a - b));
                    break;
                case '*':
                    Console.WriteLine("The sum is " + (a * b));
                    break;
                case '/':
                    Console.WriteLine("The sum is " + (a / b));
                    break;
                case '%':
                    Console.WriteLine("The modulus is " + (a % b));
                    break;
                default:
                    Console.WriteLine("Please enter valid choice");
                    break;
            }
        }
    }
}
