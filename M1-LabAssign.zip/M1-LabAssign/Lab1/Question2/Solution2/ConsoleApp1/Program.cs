﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary1;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Arithmetic Calculator");
            Console.WriteLine(" + = Addition \n - = Substartion \n  * =Multiplication \n / =Division \n % = Modulus");
            char ch = Convert.ToChar(Console.ReadLine());
            Console.WriteLine("Enter two numbers");
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());

            ArithmeticOperations obj = new ArithmeticOperations();
            obj.Math(a, b, ch);

            Console.ReadKey();


        }
    }
}
