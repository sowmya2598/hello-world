﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Employee
    {
        private int eid;
        public int Eid { get; set; }
        private string empname;
        public string EmpName { get; set; }
        private string eaddress;
        public string EAddress { get; set; }
        private string ecity;
        public string ECity { get; set; }
        private string edept;
        public string EDept { get; set; }
        private double esalary;
        public double ESalary { get; set; }

        public Employee(int id, string name, string add, string city, string dept, double sal)
        {
            this.Eid = id;
            this.EmpName = name;
            this.EAddress = add;
            this.ECity = city;
            this.EDept = dept;
            this.ESalary = sal;
        }

        public void DisplayInfo()
        {
            
            Console.WriteLine("Employee ID- " + Eid + "\n" + "Employee Name- " + EmpName + "\n" + "Employee Address- " + EAddress + "\n" + "Employee City- " + ECity + "\n" + "Employee Department- " + EDept + "\n" + "Employee Salary- " + ESalary);

        }

    }
}
