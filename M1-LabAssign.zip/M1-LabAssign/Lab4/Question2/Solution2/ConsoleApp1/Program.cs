﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class Shape
    {
        public void WhoamI()
        {
            Console.WriteLine("I m Shape");
        }
    }
    public class Triangle : Shape
    {
        public virtual void WhoamI()
        {
            Console.WriteLine("I m Triangle");
        }
    }
    public class Circle : Shape
    {
        public void WhoamI()
        {
            Console.WriteLine("I m Circle");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Shape s = new Shape();
            s.WhoamI();

            Circle c = new Circle();
            c.WhoamI();

            Triangle t = new Triangle();
            t.WhoamI();
            Console.ReadKey();
        }
    }
}
