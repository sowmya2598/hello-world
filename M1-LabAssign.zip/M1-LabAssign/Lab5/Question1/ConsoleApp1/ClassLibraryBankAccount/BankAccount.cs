﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryBankAccount
{
    public enum BankAccountTypeEnum
    {
        Current = 1,
        Saving = 2
    }
    public interface IBankAccount
    {
        double GetBalance();
        void Deposit(double amount);
        bool Withdraw(double amount);
        bool Transfer(IBankAccount toAccount, double amount);
        BankAccountTypeEnum AccountType { get; set; }
    }
    public abstract class BankAccount : IBankAccount
    {
        IBankAccount ibankaccount;
        protected double balance;

        public abstract BankAccountTypeEnum AccountType { get; set; }

        public void Deposit(double amount)
        {
            balance = balance + amount;
        }
        public double GetBalance()
        {
            return balance;
        }
        public abstract bool Withdraw(double amount);
        public abstract bool Transfer(IBankAccount toAccount, double amount);
        


    }
    public class ICICI : BankAccount
    {
        public override BankAccountTypeEnum AccountType { get; set; }
        public new void Deposit(double amount)
        {
            base.Deposit(amount);
        }
        public new void GetBalance()
        {
            Console.WriteLine(base.GetBalance());
        }
        public override bool Withdraw(double amount)
        {
            bool with = true;
            if ((balance - amount) >= 0)
            {
                balance = balance - amount;
                Console.WriteLine("Updated Balance- "+balance);
                with = true;
            }
            else
            {
                with = false;
            }
            return with;
        }
        public override bool Transfer(IBankAccount toAccount, double amount)
        {
            bool tran = true;
            if((balance-amount)>=1000)
            {
                balance = balance - amount;
                
            }
            else
            {
                tran = false;
            }
            return tran;

        }
    }

    public class HSBC : BankAccount
    {
        public override BankAccountTypeEnum AccountType { get; set; }
        public new void Deposit(double amount)
        {
            base.Deposit(amount);
        }
        public new void GetBalance()
        {
            Console.WriteLine(base.GetBalance());
        }


        public override bool Withdraw(double amount)
        {
            if((balance-amount)>=5000)
            {
                balance = balance - amount;
                return true;
            }
            else
            {
                return false;
            }
        }

        public override bool Transfer(IBankAccount toAccount, double amount)
        {
            if((balance-amount)>=5000)
            {
                balance = balance - amount;
                return true;
            }
            else
            {
                return false;
            }
            
        }
    }
}
