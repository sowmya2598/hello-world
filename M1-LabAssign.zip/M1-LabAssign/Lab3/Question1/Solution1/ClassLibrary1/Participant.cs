﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibraryException;

namespace ClassLibrary1
{
    public class Participant
    {
        private int empid;
        public int EmpID { get; set; }
        private string empname;
        public string EmpName { get; set; }
        private static string compname;
        
        private float founmarks;
        public float FounMarks
        {
            get
            {
                return founmarks;
            }

            set
            {
                if ((value > 0) && (value <= 100))
                {
                    founmarks = value;

                }
                else
                {
                    founmarks = 0;
                    throw new MyException("Marks should be greater than 0 and less than hundred");
                }
            }
        }
        private float webbasicmarks;
        public float WebBasicMarks
        {
            get
            {
                return webbasicmarks;
            }

            set
            {
                if ((value > 0) && (value <= 100))
                {
                    webbasicmarks = value;

                }
                else
                {
                    webbasicmarks = 0;
                    throw new MyException("Marks should be greater than 0 and less than hundred");
                }
            }
        }
        private float dotnetmarks;
        public float DotNetMarks
        {
            get
            {
                return dotnetmarks;
            }

            set
            {
                if ((value > 0) && (value <= 100))
                {
                    dotnetmarks = value;

                }
                else
                {
                    dotnetmarks = 0;
                    throw new MyException("Marks should be greater than 0 and less than hundred");
                }
            }
        }
        public float totalmarks=300;
        
        public float   obtmarks;
        
        public float per;
      
        public Participant()
        {
        }

        public Participant(int id, string ename, float fmarks, float wmarks, float dmarks)
        {
            this.EmpID = id;
            this.EmpName = ename;
            
            this.FounMarks = fmarks;
            this.WebBasicMarks = wmarks;
            this.DotNetMarks = dmarks;
            
          
 
        }
        static Participant()
        {
            compname = "Corporate University";
        }
       
        public void Obtained(float founmarks, float webbasicmarks, float dotnetmarks)
        {
            obtmarks = founmarks + webbasicmarks + dotnetmarks;
            Console.WriteLine("Company Name- " + compname);
            Console.WriteLine("Obtained Marks- " + obtmarks);
        }
        public float Percentage(float fmarks, float wmarks, float dmarks)
        {
            return ((fmarks + wmarks + dmarks) / totalmarks)*100;
            

            
            
        }

       
    }
}
