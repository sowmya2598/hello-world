﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary1;
using ClassLibraryException;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Enter Employee id");
                int id = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Employee Name");
                string ename = Console.ReadLine();


                Console.WriteLine("Enter Foundation marks, Webbasicmarks, dotnet marks");
                int f = int.Parse(Console.ReadLine());
                int w = int.Parse(Console.ReadLine());
                int d = int.Parse(Console.ReadLine());
                Console.WriteLine("Employee id- " + id + "\n" + "Employee Name- " + ename);



                Participant obj = new Participant(id, ename, f, w, d);
                obj.Obtained(f, w, d);
                Console.WriteLine("Percentage- " + obj.Percentage(f, w, d));
            }
            catch(MyException ex)
            {
                Console.WriteLine(ex.Message);

            }


                Console.ReadKey();



        }
    }
}
