﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Bird
    {
        public string Name;
        public double Maxheight;
        public Bird() //Default Constructor
        {
            this.Name = "Mountain Eagle";
            this.Maxheight = 500;
            //
            // TODO: Add constructor logic here
            //
        }
        public Bird(string birdname, double max_ht) //Overloaded Constructor
        {
            this.Name = "Another Bird";
            this.Maxheight = max_ht;
            Console.WriteLine(Name + "\n" + Maxheight);
        }
        public void fly()
        {
            Console.WriteLine("flying at altitude" + Maxheight);
        }
        public void fly(int AtHeight)
        {
            if (AtHeight <= Maxheight)
                Console.WriteLine(Name + " flying at " + AtHeight.ToString());
            elif:
            {


                Console.WriteLine("cannot fly at this height");
            }
        }
    }
}
        
    

