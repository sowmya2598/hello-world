﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibraryCAR;

namespace ConsoleApp1
{
    class Program
    {
        
        public static List<Car> carList = new List<Car>();
        
        static void Main(string[] args)
        {
            int choice;
            do
            {
                Console.WriteLine("1.Add a car\n2.Modify details about a car\n3.Search far a car\n4.List all cars\n5.Delete a car\n6.Exit");
                Console.WriteLine("Enter your choice");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddCar();
                        break;
                    case 2:
                        ModifyCar();
                        break;
                    case 3:
                        SearchCar();
                        break;
                    case 4:
                        ListCar();
                        break;
                    case 5:
                        DeleteCar();
                        break;
                    case 6:
                        return;
                    default:
                        break;
                }
                

               

            }
            while ((choice > 0) && (choice <= 5));
        }

        private static void AddCar()
        {
            Car newCar = new Car();
            Console.WriteLine("Enter Car make");
            newCar.CarMake = Console.ReadLine();
            Console.WriteLine("Enter Car Model");
            newCar.CarModel = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Car Year");
            newCar.CarYear = Console.ReadLine();
            Console.WriteLine("Enter Car price");
            newCar.CarPrice = double.Parse(Console.ReadLine());

            carList.Add(newCar);

            Console.WriteLine("\tCar added");
        }

        private static void ModifyCar()
        {
            Console.WriteLine("Enter model of car you want to update");
            int updateModel = int.Parse(Console.ReadLine());
            foreach(Car i in carList)
            {
                if(i.CarModel == updateModel)
                {
                    Console.WriteLine("Enter 1.To update year\n2.To update price");
                    int p = int.Parse(Console.ReadLine());
                    switch(p)
                    {
                        case 1:
                            Console.WriteLine("Enter new year");
                            i.CarYear = Console.ReadLine();
                            break;
                        case 2:
                            Console.WriteLine("Enter new price");
                            i.CarPrice = double.Parse(Console.ReadLine());
                            break;
                        default:
                            break;
                    }
                }
            }
        }

        private static void SearchCar()
        {
            Console.WriteLine("Enter model of car you want to update");
            int updateModel = int.Parse(Console.ReadLine());
            foreach (Car i in carList)
            {
                if (i.CarModel == updateModel)
                {
                    Console.WriteLine("Car found");
                    Console.WriteLine("***************************************************************");
                    Console.WriteLine("Car Make\tCar Model\tCar Year\tCar Price");
                    Console.WriteLine("***************************************************************");
                    Console.WriteLine(i.CarMake + "\t" + i.CarModel + "\t" + i.CarYear + "\t" + i.CarPrice);
                    Console.WriteLine("****************************************************************");
                }
                else
                {
                    Console.WriteLine("Car not found");
                }
            }
        }

        private static void ListCar()
        {
            if (carList != null)
            {


                Console.WriteLine("*************************************************************");
                Console.WriteLine("Car Make\tCar Model\tCar Year\tCar Price");
                Console.WriteLine("*************************************************************");
                foreach (Car i in carList)
                {
                    Console.WriteLine(i.CarMake + "\t\t" + i.CarModel + "\t\t" + i.CarYear + "\t\t" + i.CarPrice);
                    Console.WriteLine("***************************************************************");
                }
            }
            else
            {
                Console.WriteLine("No details available");
            }
        }

        private static void DeleteCar()
        {
            Car car = new Car();
            Console.WriteLine("Enter car model to delete car");
            int model = int.Parse(Console.ReadLine());
            for(int i = 0;i<carList.Count;i++)
            {
                
                if(car.CarModel == model)
                {
                    carList.RemoveAt(i);
                }
                else
                {
                    Console.WriteLine("Car not found");
                }
            }
        }







    }
}
