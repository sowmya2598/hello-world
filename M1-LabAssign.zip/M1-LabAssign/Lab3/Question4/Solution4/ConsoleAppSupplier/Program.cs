﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using ClassLibrarySupplierTest;

namespace ConsoleAppSupplier
{
    class Program
    {
        static void Main(string[] args)
        {
            SupplierTest obj = new SupplierTest();
            Console.WriteLine("Do you want to enter supplier details\n1.Yes\n2.No");
            int choice = Convert.ToInt32(Console.ReadLine());
            if (choice == 1)
            {
                obj.AcceptDetails();
            }
            else
            {
                return;
            }
            obj.DisplayDetails();
            Console.ReadKey();
        }
    }
}
