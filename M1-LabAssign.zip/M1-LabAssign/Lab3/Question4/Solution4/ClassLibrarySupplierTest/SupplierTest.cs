﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrarySupplierTest
{
    public class SupplierTest
    {
        public int SupplierID { get; set; }
        public string SupplierNAme { get; set; }
        public string SupplierCity { get; set; }
        public string PhoneNo { get; set; }
        public string SupplierEmail { get; set; }

        public SupplierTest()
        {

        }

        public SupplierTest(int id, string name, string city, string phoneno, string email)
        {
            this.SupplierID = id;
            this.SupplierNAme = name;
            this.SupplierCity = city;
            this.PhoneNo = phoneno;
            this.SupplierEmail = email;
        }


        public void AcceptDetails()
        {
            Console.WriteLine("Enter Supplier ID");
            SupplierID = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Supplier Name");
            SupplierNAme = Console.ReadLine();
            Console.WriteLine("Enter Supplier City");
            SupplierCity = Console.ReadLine();
            Console.WriteLine("Enter PhoneNo");
            PhoneNo = Console.ReadLine();
            Console.WriteLine("Enter Supplier Email");
            SupplierEmail = Console.ReadLine();



        }

        public void DisplayDetails()
        {
            Console.WriteLine("Supplier ID- " +SupplierID);
            Console.WriteLine("Supplier Name- " +SupplierNAme);
            Console.WriteLine("Supplier City- " +SupplierCity);
            Console.WriteLine("Supplier PhoneNumber- " +PhoneNo);
            Console.WriteLine("Supplier Email- " +SupplierEmail);
        }
    }
}
