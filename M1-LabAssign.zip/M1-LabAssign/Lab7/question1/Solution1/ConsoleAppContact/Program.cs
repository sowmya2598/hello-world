﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibraryContactList;

namespace ConsoleAppContact
{
    class Program
    {
        

        public static List<Contact> ContactList = new List<Contact>();
        static void Main(string[] args)
        {


            int choice;
            do
            {

                Console.WriteLine("\n\t\t1.Add Contact \n\t\t2.Display Contact \n\t\t3.Edit Contact \n\t\t4.Show All Contacts \n\t\t5.Exit");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {

                    case 1:
                        AddContact();

                        break;
                    case 2:
                        FindContact();
                        break;
                    case 3:
                        EditContact();
                        break;
                    case 4:
                        ShowAllContact();
                        break;


                    default:
                        break;
                }
            }
            while (choice != 5);
            
            
        }

            private static void AddContact()
            {
                Contact newContact = new Contact();
                Console.WriteLine("\n\t\tEnter Contact ID.- ");
                newContact.ContactID = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("\n\t\tEnter Contact name- ");
                newContact.ContactName = Console.ReadLine();
                Console.WriteLine("\n\t\tEnter Contact Number- ");
                newContact.CellNo = Console.ReadLine();

                ContactList.Add(newContact);
                Console.WriteLine("\t\tContact added \n");
            }

            private static void ShowAllContact()
            {
                Console.WriteLine("\nContactID \tContact Name \tCell Number");
                foreach (Contact i in ContactList)
                {
                
                Console.WriteLine("========================================================");
                Console.WriteLine(i.ContactID + "\t\t" + i.ContactName + "\t\t" + i.CellNo);
                Console.WriteLine("========================================================");
                }
            }

            private static void FindContact()
            {
                Console.WriteLine("\n\t\tEnter contact id to search");
                int id = Convert.ToInt32(Console.ReadLine());
                foreach(Contact i in ContactList)
                {
                    if(i.ContactID == id)
                    {
                    Console.WriteLine("ContactID \tContact Name \tCell Number");
                    Console.WriteLine("========================================================");
                    Console.WriteLine(i.ContactID + "\t\t" + i.ContactName + "\t\t" + i.CellNo);
                    Console.WriteLine("========================================================");
                }
                    else
                    {
                        Console.WriteLine("Can't find the details");
                    }
                

                
                }
            }

        private static void EditContact()
        {
            Console.WriteLine("\n\t\tEnter contact id to edit");
            int id = Convert.ToInt32(Console.ReadLine());
            foreach (Contact i in ContactList)
            {
                if (i.ContactID == id)
                {
                    Console.WriteLine("\n\t\t1.To Edit name \n 2.To edit number");
                    int option = Convert.ToInt32(Console.ReadLine());
                    switch (option)
                    {
                        case 1:
                            Console.WriteLine("\n\t\tEnter new name");
                            string ch = Console.ReadLine();
                            i.ContactName = ch;
                            Console.WriteLine(i.ContactID + "  " + i.ContactName + "  " + i.CellNo);
                            break;
                        case 2:
                            Console.WriteLine("enter new number");
                            string num = Console.ReadLine();
                            i.CellNo = num;
                            Console.WriteLine(i.ContactID + "  " + i.ContactName + "  " + i.CellNo);
                            break;
                        default:
                            Console.WriteLine("Enter valid input");
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Can't find the details");
                }
            }
        }

            
        
    }
}
