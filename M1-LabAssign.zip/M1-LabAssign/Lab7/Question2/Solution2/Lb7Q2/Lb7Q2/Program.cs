﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
namespace Lb7Q2
{
    class Program
    {
        public static ArrayList ProductList = new ArrayList();
        static void Main(string[] args)
        {
            //Creating a menu using loop and switch 
            int choice;
            do
            {
                Menu();
                Console.WriteLine("Enter Your Choice : ");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        AddProduct();
                        break;
                    case 2:
                        DeleteProduct();
                        break;
                    case 3:
                        SearchProduct();
                        break;
                    default:
                        Console.WriteLine("\nEnter A Valid Choice!!!!!");
                        break;
                }

            } while (choice != 4);
        }

        private static void Menu()
        {
            Console.WriteLine("\n\t1.To Add New Product\n\t2.To Delete A Product\n\t3.To Search A Product\n\t4.To Exit\n");
        }

        private static void AddProduct()
        {
            //To add New product in the List
            Product newProduct = new Product();
            Console.WriteLine("Enter Product number : ");
            newProduct.ProductNo = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Product Name : ");
            newProduct.ProductName = Console.ReadLine();
            Console.WriteLine("Enter Product Rate : ");
            newProduct.ProductRate = Convert.ToSingle(Console.ReadLine());
            Console.WriteLine("Enter Product stock : ");
            newProduct.Stock = Console.ReadLine();

            ProductList.Add(newProduct);
            Console.WriteLine("\nProduct Details Added!!!!!\n");

            ObjCompare obj = new ObjCompare();
            obj.ComparisonMethod = ObjCompare.ComparisonType.ProductNo;
            ProductList.Sort(obj);

        }

        private static void DeleteProduct()
        {
            //To delete a specific product from the list
            //Product P = new Product();
            int counter = 0;
            Console.WriteLine("Enter the product no. of product to be deleted : ");
            int Id = Convert.ToInt32(Console.ReadLine());

            foreach (Product P in ProductList)
            {
                if (P.ProductNo == Id)
                {
                    ProductList.Remove(P);
                    counter = 1;
                    Console.WriteLine("\nProduct Deleted!!!\n");
                    break;
                }
            }
            if (counter == 0)
            {
                Console.WriteLine("\nProduct Not Found!!!\n");
            }

        }

        private static void SearchProduct()
        {
            //To Display All The Products in The List
            Console.WriteLine("Enter the product no. of product to be searched : ");
            int Id = Convert.ToInt32(Console.ReadLine());
            int counter = 0;
            foreach (Product P in ProductList)
            {
                if (P.ProductNo == Id)
                {
                    Console.WriteLine("********************************************************************************");
                    Console.WriteLine("Product No.\tProduct Name\tRate  \tStock");
                    Console.WriteLine("********************************************************************************");
                    Console.WriteLine($"{P.ProductNo}\t\t{P.ProductName}\t{P.ProductRate}\t{P.Stock}");
                    Console.WriteLine("********************************************************************************");
                    counter = 1;
                    break;
                }
            }
            if (counter == 0)
            {
                Console.WriteLine("\n\tNo Product Found!!!!!!!!!!");
            }
        }

    }
}
