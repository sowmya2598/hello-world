﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lb7Q2
{
    public class Product
    {
        //Creating proterties of class product to hold details of product
        public int ProductNo { get; set; }
        public string ProductName { get; set; }
        public double ProductRate { get; set; }
        public string Stock { get; set; }

        public int CompareTo(Product psn2, ObjCompare.ComparisonType comparisonType, Product psn1)
        {
            int returnValue;

            if (comparisonType == ObjCompare.ComparisonType.ProductNo)
            {
                if (psn1.ProductNo == psn2.ProductNo)
                {
                    returnValue = ProductNo.CompareTo(psn2.ProductNo);
                }
                else
                {
                    returnValue = ProductNo.CompareTo(psn2.ProductNo);
                }
            }
            else
            {
                returnValue = ProductNo.CompareTo(psn2.ProductNo);
            }
            return returnValue;
        }

    }

}
