﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lb7Q2
{
    public class ObjCompare : IComparer
    {
        public enum ComparisonType
        {
            ProductNo,
            ProductName
        }

        private ComparisonType compMethod;

        public ComparisonType ComparisonMethod
        {
            get
            {
                return compMethod;
            }
            set
            {
                compMethod = value;
            }
        }

        public int Compare(object x, object y)
        {
            Product psn1 = (Product)x;
            Product psn2 = (Product)y;

            return psn1.CompareTo(psn2, ComparisonMethod, psn1);
        }
    }

}
