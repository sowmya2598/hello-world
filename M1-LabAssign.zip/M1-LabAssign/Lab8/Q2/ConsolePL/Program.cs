﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace ConsolePL
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create and return new Hashtable.
            Hashtable hashtable = new Hashtable();
            hashtable.Add("Area", 1000);
            hashtable.Add("Perimeter", 55);
            hashtable.Add("Mortgage", 540);
            //to print all the values
            foreach(int i in hashtable.Keys)
            {
                Console.WriteLine(i + " : " + hashtable[i].ToString());
            }
            //using containskey to search the key
            if (hashtable.ContainsKey("Perimeter"))
            {
                Console.WriteLine("The Key PERIMETER is present in the list");
            }
            //printing the value of area
            Console.WriteLine("The Value of Area is : " + hashtable["Area"].ToString());
            hashtable.Remove("Mortgage");
            if(hashtable.ContainsKey("Mortgage"))
                Console.WriteLine(hashtable["Mortgage"]);
            else
                Console.WriteLine("not found");
            Console.ReadKey();
        }
    }
}
