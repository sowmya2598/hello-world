﻿using System;
using System.IO;
using ClassLibrarycontact;

namespace ConsoleAppContact
{
    internal class SoapFormatter
    {
        internal void Serialize(FileStream s, Contact c)
        {
            throw new NotImplementedException();
        }
    }
}