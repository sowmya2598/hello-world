﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using ClassLibrarycontact;
namespace ConsoleAppContact
{
    class Program
    {
       public static List<Contact> con = new List<Contact>();
       // private static string fileName= "Contact.txt";

        static void Main(string[] args)
        {
            //FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read);
            //BinaryFormatter bin = new BinaryFormatter();
            //Contact desEmp = bin.Deserialize(fs) as Contact;
            //fs.Close();
            int a;
            do
            {
                Console.WriteLine("Enter choice:");
                Console.WriteLine("1.Addcontact");
                Console.WriteLine("2.Display contact");
                Console.WriteLine("3.Edit Contact");
                Console.WriteLine("4.Show all Contact:");
                Console.WriteLine("5.To delete:");
                Console.WriteLine("6.To exit");

                a = Convert.ToInt32(Console.ReadLine());
                Program c = new Program();
                switch (a)
                {
                    case 1:
                        c.Add();
                        break;
                    case 2:
                        c.Display();
                        break;
                    case 3:
                        c.EditContact();
                        break;
                    case 4:
                        c.ShowContact();
                        break;
                    case 5:
                        c.Delete();
                        break;
                    case 6:
                        break;
                    default:
                        Console.WriteLine("enter valid details:");
                        break;
                }
            }
            while (a != 6);
            Console.ReadKey();
        }
        private void Delete()
        {
            Console.WriteLine("Enter the contact no to delete");
            int id = Convert.ToInt32(Console.ReadLine());
            int c1 = 0;
            foreach (Contact c in con)
            {
                if (c.Contactno == id)
                {
                    con.Remove(c);
                    SetSerialization();

                    Console.WriteLine("Deleted");
                    c1 = 1;
                    break;
                }
            }
            if (c1 == 0)
            {
                Console.WriteLine("no match found....");
            }
        }
        private void Display()
        {
            Console.WriteLine("Enter the contact number to search:");
            int id = Convert.ToInt32(Console.ReadLine());
            int c1 = 0;
            foreach (Contact c in con)
            {
                if (c.Contactno == id)
                {
                    Console.WriteLine("contact no \t Contact Name \t Cell no");
                    Console.WriteLine("---------------------------------------");

                    Console.WriteLine(c.Contactno + "\t\t" + c.ContactName + "\t\t" + c.CellNo);

                    c1 = 1;
                    break;
                }
            }
            if (c1 == 0)
            {
                Console.WriteLine("no match found");
            }
        }
        void Add()
        {
            Contact p = new Contact();
            Console.WriteLine("Enter Contact no:");
            p.Contactno = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Contact name:");
            p.ContactName = (Console.ReadLine());
            Console.WriteLine("Enter Cell no:");
            p.CellNo = Convert.ToInt64(Console.ReadLine());

            con.Add(p);
            
            Console.WriteLine("file added!!");
            Console.WriteLine();
            SetSerialization();


        }
        public void EditContact()
        {
            Console.WriteLine("Enter the contact no to edit");
            int id = Convert.ToInt32(Console.ReadLine());
            int c1 = 0;
            foreach (Contact c in con)
            {
                if (c.Contactno == id)
                {
                    Console.WriteLine("enter new Contact name:");
                    c.ContactName = Console.ReadLine();
                    Console.WriteLine("Enter the cell no:");
                    c.CellNo = Convert.ToInt32(Console.ReadLine());
                    c1 = 1;
                    Console.WriteLine("Changed....");
                    Console.WriteLine();
                }
            }
            if (c1 == 0)
            {
                Console.WriteLine("no id found");
            }
        }
        public void ShowContact()
        {
            DeserializeData();
            Console.WriteLine("contact no \tContact Name \tCell no");
            Console.WriteLine("------------------------------------------");
            foreach (Contact s in con)
            {
                Console.WriteLine(s.Contactno + "\t\t" + s.ContactName + "\t\t" + s.CellNo);
            }
        }
        //public static void setlist()
        //{
        //    try
        //    {
        //        if (File.Exists(Directory.GetCurrentDirectory() + "\\" + fileName))
        //            Contact.SetList();
        //    }
        //    catch (Exception ex)
        //    {
        //        Console.WriteLine(ex.Message);
        //    }

        //}
        public static void SetSerialization()
        {
            Contact c = new Contact();
            //FileStream fileStream = new FileStream("d:\\ser.dat", FileMode.Create);
            //BinaryFormatter binaryFormatter = new BinaryFormatter();
            //binaryFormatter.Serialize(fileStream, con);
            //fileStream.Close();
           // ClassToSerialize c = new ClassToSerialize();
            FileStream s= File.Open("temp.xml", FileMode.Create,FileAccess.ReadWrite);
            SoapFormatter sf1 = new SoapFormatter();
            sf1.Serialize(s, c);
            s.Close();
        }
        private static void DeserializeData()
        {
            FileStream fileStream = new FileStream("d:\\ser.dat", FileMode.Open);
            BinaryFormatter binaryFormatter = new BinaryFormatter();
             con = binaryFormatter.Deserialize(fileStream) as List<Contact>; ;
            fileStream.Close();
           // Console.WriteLine(dt.ToString());
        }

    }
}

