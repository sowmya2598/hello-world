﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace eshoppyEntities
{
    [Serializable]
    public class Dealers
    {
        public int DealerCode { get; set; }
        public string OrganizationName { get; set; }
        public string ContactPerson { get; set; }
        public double ContactNumber { get; set; }
        public string Address_Warehouse { get; set; }
        public string OfficialEmail { get; set; }
        public string Address_RegdOffice { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
