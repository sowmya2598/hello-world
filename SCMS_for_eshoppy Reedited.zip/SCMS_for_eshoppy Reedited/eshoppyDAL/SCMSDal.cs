﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using eshoppyEntities;
using eshoppyExceptions;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace eshoppyDAL
{
    public class SCMSDal
    {
        public static List<Products> productList = new List<Products>();
        public static List<ProductOrders> productorderList = new List<ProductOrders>();
        public static List<Customers> customerList = new List<Customers>();
        public static List<Dealers> dealerList = new List<Dealers>();
        public static string fileName = "ProductList";



        public static bool AddProductDAL(Products newProduct)
        {
            bool productAdded = false;
            try
            {
                productList.Add(newProduct);
                productAdded = true;
                SetSerialization();
            }
            catch (Exception ex)
            {
                throw new eshoppyExceptions.SCMSException(ex.Message);
            }
            return productAdded;
        }

        public static List<Products> GetAllProductsDAL()
        {
            return productList;
        }


        //public static bool AddProductByDealerDAL(Products newProduct)
        //{
        //    bool productAddedByDealer = false;
        //    try
        //    {
        //        productList.Add(newProduct);
        //        productAddedByDealer = true;
        //        SetSerialization();
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new eshoppyExceptions.SCMSException(ex.Message);
        //    }
        //    return productAddedByDealer;
        //}

        //public static List<Products> GetAllProductsByDealerDAL()
        //{
        //    return productList;
        //}



        public static bool PlaceProductOrderDAL(ProductOrders newProductOrder)
        {
            bool productorderPlaced = false;
            try
            {
                productorderList.Add(newProductOrder);
                productorderPlaced = true;
                SetSerialization();
            }
            catch (Exception ex)
            {
                throw new eshoppyExceptions.SCMSException(ex.Message);
            }
            return productorderPlaced;
        }


        public static List<ProductOrders> GetAllProductOrdersDAL()
        {
            return productorderList;
        }

        public static bool RemoveProductDAL(int removeProductId)
        {
            bool productRemoved = false;
            try
            {
                //for (int i = 0; i < productList.Count; i++)
                //{
                //    Products product = productList[i];
                //    if (product.ProductId == removeProductId)
                //    {
                //        productList.RemoveAt(i);
                //        productRemoved = true;
                //        SetSerialization();
                //        break;
                //    }
                //}



                Products product = productList.Find(products => products.ProductId == removeProductId);

                if (product != null)
                {
                    productList.Remove(product);
                    productRemoved = true;
                    SetSerialization();
                   
                }

            }
            catch (Exception ex)
            {
                throw new eshoppyExceptions.SCMSException(ex.Message);
            }
            return productRemoved;
        }

        public static bool CancelProductOrderDAL(int cancelProductOrderId)
        {
            bool productorderCancelled = false;
            try
            {
                ProductOrders productorder = productorderList.Find(productorders => productorders.ProductId == cancelProductOrderId);

                if (productorder != null)
                {
                    productorderList.Remove(productorder);
                    productorderCancelled = true;
                    SetSerialization();
                    
                }
                //for (int i = 0; i < productorderList.Count; i++)
                //{
                //    ProductOrders productorder = productorderList[i];
                //    if (productorder.ProductOrderId == cancelProductOrderId)
                //    {
                //        productorderList.RemoveAt(i);
                //        productorderCancelled = true;
                //        SetSerialization();
                //        break;
                //    }
                //}

            }
            catch (Exception ex)
            {
                throw new eshoppyExceptions.SCMSException(ex.Message);
            }
            return productorderCancelled;
        }

        public static bool CancelProductOrderByCustomerDAL(int cancelProductOrderIdByCustomer)
        {
            bool productorderCancelledByCustomer = false;
            try
            {

                ProductOrders productorder = productorderList.Find(productorders => productorders.ProductId == cancelProductOrderIdByCustomer);

                if (productorder != null)
                {
                    productorderList.Remove(productorder);
                    productorderCancelledByCustomer = true;
                    SetSerialization();
                    
                }


                //for (int i = 0; i < productorderList.Count; i++)
                //{
                //    ProductOrders productorder = productorderList[i];
                //    if (productorder.ProductOrderId == cancelProductOrderIdByCustomer)
                //    {
                //        productorderList.RemoveAt(i);
                //        productorderCancelledByCustomer = true;
                //        SetSerialization();
                //        break;
                //    }
                //}

            }
            catch (Exception ex)
            {
                throw new eshoppyExceptions.SCMSException(ex.Message);
            }
            return productorderCancelledByCustomer;
        }

        public static bool CancelProductOrderByDealerDAL(int cancelProductOrderIdByDealer)
        {
            bool productorderCancelledByDealer = false;
            try
            {
                ProductOrders productorder = productorderList.Find(productorders => productorders.ProductId == cancelProductOrderIdByDealer);

                if (productorder != null)
                {
                    productorderList.Remove(productorder);
                    productorderCancelledByDealer = true;
                    SetSerialization();
                   
                }


                //for (int i = 0; i < productorderList.Count; i++)
                //{
                //    ProductOrders productorder = productorderList[i];
                //    if (productorder.ProductOrderId == cancelProductOrderIdByDealer)
                //    {
                //        productorderList.RemoveAt(i);
                //        productorderCancelledByDealer = true;
                //        SetSerialization();
                //        break;
                //    }
                //}

            }
            catch (Exception ex)
            {
                throw new eshoppyExceptions.SCMSException(ex.Message);
            }
            return productorderCancelledByDealer;
        }


        public static bool UpdateProductDAL(Products updateProduct)
        {
            bool productUpdated = false;
            try
            {
                for (int i = 0; i < productList.Count; i++)
                {
                    Products product = productList[i];
                    if (product.ProductId == updateProduct.ProductId)
                    {
                        productList[i] = updateProduct;
                        SetSerialization();
                        break;
                    }
                }
                productUpdated = true;
            }
            catch (Exception ex)
            {
                throw new eshoppyExceptions.SCMSException(ex.Message);
            }
            return productUpdated;
        }



        //public static bool UpdateProductByDealerDAL(Products updateProductByDealer)
        //{
        //    bool productUpdatedByDealer = false;
        //    try
        //    {
        //        for (int i = 0; i < productList.Count; i++)
        //        {
        //            Products product = productList[i];
        //            if (product.ProductId == updateProductByDealer.ProductId)
        //            {
        //                productList[i] = updateProductByDealer;
        //                SetSerialization();
        //                break;
        //            }
        //        }
        //        productUpdatedByDealer = true;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new eshoppyExceptions.SCMSException(ex.Message);
        //    }
        //    return productUpdatedByDealer;
        //}



        public static Products SearchProductDAL(int searchProductID)
        {
            Products searchProduct = null;
            try
            {
                for (int i = 0; i < productList.Count; i++)
                {
                    Products product = productList[i];
                    if (product.ProductId == searchProductID)
                    {
                        searchProduct = productList[i];
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new eshoppyExceptions.SCMSException(ex.Message);
            }
            return searchProduct;
        }
        public static ProductOrders SearchProductOrderDAL(int searchProductOrderID)
        {
            ProductOrders searchProductOrder = null;
            try
            {
                for (int i = 0; i < productorderList.Count; i++)
                {
                    ProductOrders productorder = productorderList[i];
                    if (productorder.ProductOrderId == searchProductOrderID)
                    {
                        searchProductOrder = productorderList[i];
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new eshoppyExceptions.SCMSException(ex.Message);
            }
            return searchProductOrder;
        }

        ////public static Products SearchProductByDealerDAL(int searchProductIDByDealer)
        ////{
        ////    Products searchProductByDealer = null;
        ////    try
        ////    {
        ////        for (int i = 0; i < productList.Count; i++)
        ////        {
        ////            Products product = productList[i];
        ////            if (product.ProductId == searchProductIDByDealer)
        ////            {
        ////                searchProductByDealer = productList[i];
        ////                break;
        ////            }
        ////        }
        ////    }
        ////    catch (Exception ex)
        ////    {
        ////        throw new eshoppyExceptions.SCMSException(ex.Message);
        ////    }
        ////    return searchProductByDealer;
        ////}
        //public static ProductOrders SearchProductOrderByDealerDAL(int searchProductOrderIDByDealer)
        //{
        //    ProductOrders searchProductOrderByDealer = null;
        //    try
        //    {
        //        for (int i = 0; i < productorderList.Count; i++)
        //        {
        //            ProductOrders productorder = productorderList[i];
        //            if (productorder.ProductOrderId == searchProductOrderIDByDealer)
        //            {
        //                searchProductOrderByDealer = productorderList[i];
        //                break;
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new eshoppyExceptions.SCMSException(ex.Message);
        //    }
        //    return searchProductOrderByDealer;
        //}


        ////public static Products SearchProductByCustomerDAL(int searchProductIDByCustomer)
        ////{
        ////    Products searchProductByCustomer = null;
        ////    try
        ////    {
        ////        for (int i = 0; i < productList.Count; i++)
        ////        {
        ////            Products product = productList[i];
        ////            if (product.ProductId == searchProductIDByCustomer)
        ////            {
        ////                searchProductByCustomer = productList[i];
        ////                break;
        ////            }
        ////        }
        ////    }
        ////    catch (Exception ex)
        ////    {
        ////        throw new eshoppyExceptions.SCMSException(ex.Message);
        ////    }
        ////    return searchProductByCustomer;
        ////}
        //public static ProductOrders SearchProductOrderByCustomerDAL(int searchProductOrderIDByCustomer)
        //{
        //    ProductOrders searchProductOrderByCustomer = null;
        //    try
        //    {
        //        for (int i = 0; i < productorderList.Count; i++)
        //        {
        //            ProductOrders productorder = productorderList[i];
        //            if (productorder.ProductOrderId == searchProductOrderIDByCustomer)
        //            {
        //                searchProductOrderByCustomer = productorderList[i];
        //                break;
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new eshoppyExceptions.SCMSException(ex.Message);
        //    }
        //    return searchProductOrderByCustomer;
        //}



        public static bool RegisterAsDealerDAL(Dealers newDealer)
        {
            bool dealerRegistered = false;
            try
            {
                dealerList.Add(newDealer);
                dealerRegistered = true;
                SetSerialization();
            }
            catch (Exception ex)
            {
                throw new eshoppyExceptions.SCMSException(ex.Message);
            }
            return dealerRegistered;
        }

        public static List<Dealers> GetAllDealersDAL()
        {
            return dealerList;
        }



        public static bool RegisterAsCustomerDAL(Customers newCustomer)
        {
            bool customerRegistered = false;
            try
            {
                customerList.Add(newCustomer);
                customerRegistered = true;
                SetSerialization();
            }
            catch (Exception ex)
            {
                throw new eshoppyExceptions.SCMSException(ex.Message);
            }
            return customerRegistered;
        }

        public static List<Customers> GetAllCustomersDAL()
        {
            return customerList;
        }



        //public static List<ProductOrders> AdminPendingOrdersList()
        //{

        //}

        //public static List<ProductOrders> DealerPendingOrdersList()
        //{

        //}




        public static void SetSerialization()
        {
            try
            {
                using (Stream file = File.Open(fileName, FileMode.Create))
                {
                    BinaryFormatter bf = new BinaryFormatter();
                    bf.Serialize(file, productList);
                    bf.Serialize(file, productorderList);
                    bf.Serialize(file, dealerList);
                    bf.Serialize(file, customerList);
                    file.Close();
                }
            }
            catch (FileNotFoundException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        public static void SetList()
        {
            DeserializeFile();
        }
        public static void DeserializeFile()
        {
            try
            {
                using (Stream file = File.Open(Directory.GetCurrentDirectory() + "\\" + fileName, FileMode.Open))
                {
                    BinaryFormatter bf = new BinaryFormatter();
                    productList = bf.Deserialize(file) as List<Products>;
                    productorderList = bf.Deserialize(file) as List<ProductOrders>;
                    dealerList = bf.Deserialize(file) as List<Dealers>;
                    customerList = bf.Deserialize(file) as List<Customers>;
                    file.Close();
                }
            }
            catch (FileNotFoundException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

    }
}
